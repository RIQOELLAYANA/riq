# Selfbot Line Python
## Basic From HelloWorld/Hellomod
### Jika sudah di run, ketik "help" untuk melihat semua keycommandnya
## Installation for Termux
///////////////////////////////////////////////////////
<br> pkg install python3 -y
<br> apt-get install python --upgrade
<br> pkg install git -y
<br> pkg install nano -y
<br> pip3 install rsa
<br> pip3 install thrift==0.11.0
<br> pip3 install requests
<br> pip3 install bs4
<br> pip3 install gtts
<br> pip3 install beautifulsoup
<br> pip3 install humanfriendly
<br> pip3 install goslate
<br> pip3 install wikipedia
<br> pip3 install youtube_dl
<br> pip3 install tweepy
<br> pip3 install pytz
<br> pip3 install html5lib
<br> pip3 install pafy
<br> pip3 install timeago
<br> pip3 install livejson
<br> pip3 install humanize
<br>git clone https://github.com/imbobb/HelloBobby
<br>ls
<br>cd HelloBobby
<br>ls
<br>nano sb.py 
<br>(input Email & Pass)
<br>ctrl+x
<br>y -> enter
<br>python3 sb.py
## Installation for VPS
///////////////////////////////////////////////////////
<br> sudo apt-get update
<br> sudo apt-get install git
<br> sudo apt-get install python3-pip
<br> sudo pip3 install rsa
<br> sudo pip3 install thrift==0.11.0
<br> sudo pip3 install requests
<br> sudo pip3 install bs4
<br> sudo pip3 install gtts
<br> sudo pip3 install beautifulsoup
<br> sudo pip3 install humanfriendly
<br> sudo pip3 install goslate
<br> sudo pip3 install wikipedia
<br> sudo pip3 install youtube_dl
<br> sudo pip3 install tweepy
<br> sudo pip3 install pytz
<br> sudo pip3 install timeago
<br> sudo pip3 install html5lib
<br> sudo pip3 install pafy
<br> sudo pip3 install livejson
<br> sudo pip3 install humanize
<br>git clone https://github.com/imbobb/HelloBobby
<br>ls
<br>cd HelloBobby
<br>ls
<br>nano sb.py
<br>(input Email & Pass)
<br>ctrl+x
<br>y -> enter
<br>python3 sb.py

# NOTE
<br>BUAT YG MAU UBAH SILAHKAN UP SUKA SUKA

# SPECIAL THANKS TO
<br>• Arifistifik / <a href="https://github.com/arifistifik">@arifistifik</a>
<br>• Team Newbie Corps™

# SUPPORTED BY
<br>• <a href="https://lin.ee/hzZujuI">We Bare Bears Corps™</a>
<br>• <a href="https://lin.ee/emt8het">B-G-N Squad</a>

# ADD MY LINE
<br> <a href="https://line.me/ti/p/~imbobby_">`B O B B Y™</a>
