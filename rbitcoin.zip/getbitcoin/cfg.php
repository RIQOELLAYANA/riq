<?php

//BAHAN YANG PERLU DIINSTAL DI TERMUX
//[1]. pkg install php
//[2]. pkg install tesseract
//[3]. pkg install imagemagick
//Sampai Sini sudah Paham Kan 
//Jangan Lupa Subscribe Chanel Penghasil Gratisa


$ua = "Mozilla/5.0 (Linux; Android 10; SM-J400F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Mobile Safari/537.36";

$PHPSESSID = "PHPSESSID=8hl8mdlnnjtncbe2jg1suqvurj";

$get_id = "get_id=134819";